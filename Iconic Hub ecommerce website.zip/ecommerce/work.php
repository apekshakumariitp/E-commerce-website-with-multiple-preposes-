<?php include('header.php'); ?>
  
  <style>

    .portfolio-section {
      padding: 60px 20px;
      max-width: 1200px;
      margin: auto;
    }

    .portfolio-section h2 {
      text-align: center;
      color: #f38a17;
      margin-bottom: 30px;
      font-weight: bold;
    }

    .filter-buttons {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      gap: 10px;
      margin-bottom: 40px;
    }

    .filter-buttons button {
      background: #1c1c1c;
      color: #fff;
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      transition: 0.3s ease;
    }

    .filter-buttons button.active,
    .filter-buttons button:hover {
      background: #f38a17;
      color: #000;
    }

    .portfolio-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
      gap: 20px;
    }

    .portfolio-item {
      background: #1c1c1c;
      border-radius: 10px;
      overflow: hidden;
      cursor: pointer;
      transition: transform 0.3s ease;
    }

    .portfolio-item:hover {
      transform: scale(1.03);
    }

    .portfolio-item img {
      width: 100%;
      height: 180px;
      object-fit: cover;
      display: block;
    }

    .portfolio-item h4 {
      text-align: center;
      padding: 10px;
      color: #f38a17;
      font-size: 16px;
    }

    /* Lightbox */
    .lightbox {
      display: none;
      position: fixed;
      z-index: 9999;
      top: 0; left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0,0,0,0.9);
      justify-content: center;
      align-items: center;
    }

    .lightbox img {
      max-width: 90%;
      max-height: 90%;
      border: 4px solid #f38a17;
      border-radius: 10px;
    }

    .lightbox-close {
      position: absolute;
      top: 20px;
      right: 30px;
      color: #fff;
      font-size: 30px;
      cursor: pointer;
    }
  </style>

<section class="portfolio-section">
  <h2>Our Work</h2>

  <div class="filter-buttons">
    <button class="active" onclick="filterPortfolio('all')">All</button>
    <button onclick="filterPortfolio('website')">Website</button>
    <button onclick="filterPortfolio('graphic')">Graphic</button>
    <button onclick="filterPortfolio('video')">Video</button>
  </div>

  <div class="portfolio-grid" id="portfolioGrid">
    <!-- Website Work -->
    <div class="portfolio-item" data-category="website" onclick="openLightbox('portfolio/site1.jpg')">
      <img src="portfolio/site1.jpg" alt="Website Work">
      <h4>Business Website</h4>
    </div>

    <div class="portfolio-item" data-category="website" onclick="openLightbox('portfolio/site2.jpg')">
      <img src="portfolio/site2.jpg" alt="Website Work">
      <h4>Landing Page</h4>
    </div>

    <!-- Graphic Work -->
    <div class="portfolio-item" data-category="graphic" onclick="openLightbox('work/1.jpg')">
      <img src="work/1.jpg" alt="Graphic Design">
      <h4>Social Media Banner</h4>
    </div>

    <div class="portfolio-item" data-category="graphic" onclick="openLightbox('portfolio/graphic2.jpg')">
      <img src="portfolio/graphic2.jpg" alt="Graphic Design">
      <h4>Logo Design</h4>
    </div>

    <!-- Video Work -->
    <div class="portfolio-item" data-category="video" onclick="openLightbox('portfolio/video-thumbnail.jpg')">
      <img src="portfolio/video-thumbnail.jpg" alt="Video Editing">
      <h4>Promo Video</h4>
    </div>

    <!-- You can add more portfolio items below using same structure -->
  </div>
</section>

<!-- Lightbox -->
<div class="lightbox" id="lightbox">
  <span class="lightbox-close" onclick="closeLightbox()">&times;</span>
  <img id="lightboxImage" src="" alt="Preview">
</div>

<script>
  function filterPortfolio(category) {
    const buttons = document.querySelectorAll('.filter-buttons button');
    buttons.forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');

    const items = document.querySelectorAll('.portfolio-item');
    items.forEach(item => {
      const itemCat = item.getAttribute('data-category');
      if (category === 'all' || itemCat === category) {
        item.style.display = 'block';
      } else {
        item.style.display = 'none';
      }
    });
  }

  function openLightbox(src) {
    document.getElementById('lightboxImage').src = src;
    document.getElementById('lightbox').style.display = 'flex';
  }

  function closeLightbox() {
    document.getElementById('lightbox').style.display = 'none';
  }
</script>



<?php include('footer.php'); ?>