<?php include('header.php'); ?>

<style>
.services-container {
  max-width: 1100px;
  margin: auto;
  padding: 60px 20px;
}
.services-container h2 {
  text-align: center;
  font-size: 36px;
  color: #f38a17;
  margin-bottom: 30px;
  font-weight: bold;
}
.service-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 25px;
}
.service-card {
  background: #1c1c1c;
  color: #fff;
  padding: 30px 20px;
  border-radius: 12px;
  box-shadow: 0 0 12px rgba(0,0,0,0.3);
  transition: 0.4s ease;
  text-align: center;
}
.service-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 0 18px #f38a17;
}
.service-card i {
  font-size: 36px;
  color: #f38a17;
  margin-bottom: 15px;
}
.service-card h4 {
  font-size: 20px;
  margin-bottom: 10px;
}
.service-card p {
  font-size: 14px;
  line-height: 1.5;
  color: #ccc;
}

.service-cta {
  text-align: center;
  margin-top: 50px;
}
.service-cta a {
  background: #f38a17;
  color: #000;
  padding: 12px 30px;
  border-radius: 6px;
  font-weight: bold;
  text-decoration: none;
  transition: 0.3s ease;
}
.service-cta a:hover {
  background: #e27c13;
}
</style>

<section class="services-container">
  <h2>Our Services</h2>

  <div class="service-grid">
    <div class="service-card">
      <i class="fas fa-code"></i>
      <h4>Web & App Development</h4>
      <p>Custom websites, business portals, and mobile apps tailored to your goals.</p>
    </div>

    <div class="service-card">
      <i class="fas fa-paint-brush"></i>
      <h4>Graphic Design</h4>
      <p>Logos, brochures, posters, banners, and all your branding needs beautifully crafted.</p>
    </div>

    <div class="service-card">
      <i class="fas fa-pencil-ruler"></i>
      <h4>UI/UX Design</h4>
      <p>We design intuitive and attractive interfaces that users love to explore.</p>
    </div>

    <div class="service-card">
      <i class="fas fa-video"></i>
      <h4>Video Editing</h4>
      <p>Promos, reels, YouTube edits, and corporate videos with smooth transitions and effects.</p>
    </div>

    <div class="service-card">
      <i class="fas fa-film"></i>
      <h4>Animation & VFX</h4>
      <p>Bring ideas to life with 2D/3D animations, explainer videos, and motion graphics.</p>
    </div>

    <div class="service-card">
      <i class="fas fa-tshirt"></i>
      <h4>Printing Services</h4>
      <p>We print on t-shirts, caps, mugs, and more—with custom designs or your brand identity.</p>
    </div>
  </div>

  <div class="service-cta">
    <a href="contact.php">Need Custom Service? Let's Talk</a>
  </div>
</section>

<?php include('footer.php'); ?>
