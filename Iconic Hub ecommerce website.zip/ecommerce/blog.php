<?php include('header.php'); ?>

<!-- Font Awesome for Icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />

<section class="blog-video-section" style="background:#121212; color:#fff; padding: 60px 20px;">
  <div class="container" style="max-width: 1200px; margin: auto;">
    <h2 style="color:#f38a17; text-align:center; margin-bottom:40px; font-weight:bold;">Our Blog Videos</h2>

    <div class="video-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px;">
      
      <!-- Video Card -->
      <div class="video-card" data-video-id="VIDEO_ID_1" style="background:#1c1c1c; padding:20px; border-radius:12px;">
        <div style="position:relative; padding-bottom:56.25%; height:0; overflow:hidden; border-radius:8px;">
          <iframe src="https://www.youtube.com/embed/VIDEO_ID_1"
                  frameborder="0" allowfullscreen
                  style="position:absolute; top:0; left:0; width:100%; height:100%;">
          </iframe>
        </div>
        <h3 style="margin-top:15px;">Your Video Title 1</h3>
        <p style="color:#ccc;">A short description about this blog video.</p>

        <div class="video-stats" style="display:flex; align-items:center; gap:10px; margin-top:10px; flex-wrap:wrap;">
          <button style="background:#f38a17; border:none; padding:8px 12px; border-radius:5px;">
            <i class="fas fa-thumbs-up"></i> <span class="likes-count">--</span>
          </button>
          <button style="background:#f38a17; border:none; padding:8px 12px; border-radius:5px;">
            <i class="fas fa-thumbs-down"></i>
          </button>
          <button style="background:#f38a17; border:none; padding:8px 12px; border-radius:5px;">
            <i class="fas fa-comment"></i> <span class="comment-count">--</span>
          </button>
          <a href="https://www.youtube.com/channel/YOUR_CHANNEL_ID?sub_confirmation=1"
             target="_blank"
             style="margin-left:auto; background:#f38a17; color:#000; padding:8px 16px; border-radius:5px; font-weight:bold; text-decoration:none;">
            <i class="fab fa-youtube"></i> Subscribe
          </a>
        </div>
      </div>

      <div class="video-card" data-video-id="VIDEO_ID_2" style="background:#1c1c1c; padding:20px; border-radius:12px;">
        <div style="position:relative; padding-bottom:56.25%; height:0; overflow:hidden; border-radius:8px;">
          <iframe src="https://www.youtube.com/embed/VIDEO_ID_2"
                  frameborder="0" allowfullscreen
                  style="position:absolute; top:0; left:0; width:100%; height:100%;">
          </iframe>
        </div>
        <h3 style="margin-top:15px;">Your Video Title 2</h3>
        <p style="color:#ccc;">Another description about this blog video.</p>

        <div class="video-stats" style="display:flex; align-items:center; gap:10px; margin-top:10px; flex-wrap:wrap;">
          <button style="background:#f38a17; border:none; padding:8px 12px; border-radius:5px;">
            <i class="fas fa-thumbs-up"></i> <span class="likes-count">--</span>
          </button>
          <button style="background:#f38a17; border:none; padding:8px 12px; border-radius:5px;">
            <i class="fas fa-thumbs-down"></i>
          </button>
          <button style="background:#f38a17; border:none; padding:8px 12px; border-radius:5px;">
            <i class="fas fa-comment"></i> <span class="comment-count">--</span>
          </button>
          <a href="https://www.youtube.com/channel/YOUR_CHANNEL_ID?sub_confirmation=1"
             target="_blank"
             style="margin-left:auto; background:#f38a17; color:#000; padding:8px 16px; border-radius:5px; font-weight:bold; text-decoration:none;">
            <i class="fab fa-youtube"></i> Subscribe
          </a>
        </div>
      </div>

      <div class="video-card" data-video-id="VIDEO_ID_2" style="background:#1c1c1c; padding:20px; border-radius:12px;">
        <div style="position:relative; padding-bottom:56.25%; height:0; overflow:hidden; border-radius:8px;">
          <iframe src="https://www.youtube.com/embed/VIDEO_ID_2"
                  frameborder="0" allowfullscreen
                  style="position:absolute; top:0; left:0; width:100%; height:100%;">
          </iframe>
        </div>
        <h3 style="margin-top:15px;">Your Video Title 2</h3>
        <p style="color:#ccc;">Another description about this blog video.</p>

        <div class="video-stats" style="display:flex; align-items:center; gap:10px; margin-top:10px; flex-wrap:wrap;">
          <button style="background:#f38a17; border:none; padding:8px 12px; border-radius:5px;">
            <i class="fas fa-thumbs-up"></i> <span class="likes-count">--</span>
          </button>
          <button style="background:#f38a17; border:none; padding:8px 12px; border-radius:5px;">
            <i class="fas fa-thumbs-down"></i>
          </button>
          <button style="background:#f38a17; border:none; padding:8px 12px; border-radius:5px;">
            <i class="fas fa-comment"></i> <span class="comment-count">--</span>
          </button>
          <a href="https://www.youtube.com/channel/YOUR_CHANNEL_ID?sub_confirmation=1"
             target="_blank"
             style="margin-left:auto; background:#f38a17; color:#000; padding:8px 16px; border-radius:5px; font-weight:bold; text-decoration:none;">
            <i class="fab fa-youtube"></i> Subscribe
          </a>
        </div>
      </div>

      <div class="video-card" data-video-id="VIDEO_ID_2" style="background:#1c1c1c; padding:20px; border-radius:12px;">
        <div style="position:relative; padding-bottom:56.25%; height:0; overflow:hidden; border-radius:8px;">
          <iframe src="https://www.youtube.com/embed/VIDEO_ID_2"
                  frameborder="0" allowfullscreen
                  style="position:absolute; top:0; left:0; width:100%; height:100%;">
          </iframe>
        </div>
        <h3 style="margin-top:15px;">Your Video Title 2</h3>
        <p style="color:#ccc;">Another description about this blog video.</p>

        <div class="video-stats" style="display:flex; align-items:center; gap:10px; margin-top:10px; flex-wrap:wrap;">
          <button style="background:#f38a17; border:none; padding:8px 12px; border-radius:5px;">
            <i class="fas fa-thumbs-up"></i> <span class="likes-count">--</span>
          </button>
          <button style="background:#f38a17; border:none; padding:8px 12px; border-radius:5px;">
            <i class="fas fa-thumbs-down"></i>
          </button>
          <button style="background:#f38a17; border:none; padding:8px 12px; border-radius:5px;">
            <i class="fas fa-comment"></i> <span class="comment-count">--</span>
          </button>
          <a href="https://www.youtube.com/channel/YOUR_CHANNEL_ID?sub_confirmation=1"
             target="_blank"
             style="margin-left:auto; background:#f38a17; color:#000; padding:8px 16px; border-radius:5px; font-weight:bold; text-decoration:none;">
            <i class="fab fa-youtube"></i> Subscribe
          </a>
        </div>
      </div>

      <!-- Add more video cards here -->
      <div class="video-card" data-video-id="VIDEO_ID_2" style="background:#1c1c1c; padding:20px; border-radius:12px;">
        <div style="position:relative; padding-bottom:56.25%; height:0; overflow:hidden; border-radius:8px;">
          <iframe src="https://www.youtube.com/embed/VIDEO_ID_2"
                  frameborder="0" allowfullscreen
                  style="position:absolute; top:0; left:0; width:100%; height:100%;">
          </iframe>
        </div>
        <h3 style="margin-top:15px;">Your Video Title 2</h3>
        <p style="color:#ccc;">Another description about this blog video.</p>

        <div class="video-stats" style="display:flex; align-items:center; gap:10px; margin-top:10px; flex-wrap:wrap;">
          <button style="background:#f38a17; border:none; padding:8px 12px; border-radius:5px;">
            <i class="fas fa-thumbs-up"></i> <span class="likes-count">--</span>
          </button>
          <button style="background:#f38a17; border:none; padding:8px 12px; border-radius:5px;">
            <i class="fas fa-thumbs-down"></i>
          </button>
          <button style="background:#f38a17; border:none; padding:8px 12px; border-radius:5px;">
            <i class="fas fa-comment"></i> <span class="comment-count">--</span>
          </button>
          <a href="https://www.youtube.com/channel/YOUR_CHANNEL_ID?sub_confirmation=1"
             target="_blank"
             style="margin-left:auto; background:#f38a17; color:#000; padding:8px 16px; border-radius:5px; font-weight:bold; text-decoration:none;">
            <i class="fab fa-youtube"></i> Subscribe
          </a>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- JS to Fetch Like and Comment Counts -->
<script>
  const apiKey = "YOUR_YOUTUBE_API_KEY";

  document.querySelectorAll('.video-card').forEach(card => {
    const videoId = card.getAttribute('data-video-id');
    const likeSpan = card.querySelector('.likes-count');
    const commentSpan = card.querySelector('.comment-count');

    fetch(`https://www.googleapis.com/youtube/v3/videos?part=statistics&id=${videoId}&key=${apiKey}`)
      .then(response => response.json())
      .then(data => {
        const stats = data.items[0]?.statistics;
        if (stats) {
          likeSpan.textContent = stats.likeCount || '0';
          commentSpan.textContent = stats.commentCount || '0';
        } else {
          likeSpan.textContent = '0';
          commentSpan.textContent = '0';
        }
      })
      .catch(error => {
        console.error("YouTube API error:", error);
        likeSpan.textContent = '--';
        commentSpan.textContent = '--';
      });
  });
</script>




<?php include('footer.php'); ?>