<footer style="background: #1c1c1c; color: #fff; padding: 60px 20px 20px;" id="footer">
  <div class="container">
    <div class="row" style="display: flex; flex-wrap: wrap; gap: 30px; justify-content: space-between;">

      <!-- Logo & Description -->
      <div style="flex: 1 1 250px;">
        <img src="logo/Hub logo website.png" alt="Charlie Creation" style="width: 200px; margin-bottom: 15px;">
        <p style="line-height: 1.6;">conic Hub is your ultimate fashion destination, curating exceptional styles in clothing, footwear, and handbags — from trendsetting designs to doorstep delivery.</p>
      </div>

      <!-- Quick Links -->
      <div style="flex: 1 1 150px;">
        <h4 style="color: #f38a17;">Quick Links</h4>
        <ul style="list-style: none; padding: 0;">
          <li><a href="#home" style="color: #ccc; text-decoration: none;">Home</a></li>
          <li><a href="#about" style="color: #ccc; text-decoration: none;">About</a></li>
          <li><a href="#services" style="color: #ccc; text-decoration: none;">Services</a></li>
          <li><a href="#testimonials" style="color: #ccc; text-decoration: none;">Feedback</a></li>
          <li><a href="contact.html" style="color: #ccc; text-decoration: none;">Contact</a></li>
        </ul>
      </div>

      <!-- Contact Info -->
      <div style="flex: 1 1 200px;">
        <h4 style="color: #f38a17;">Contact</h4>
        <p><i class="fas fa-map-marker-alt" style="color: #f38a17;"></i> Ranchi, Jharkhand, India</p>
        <p><i class="fas fa-phone-alt" style="color: #f38a17;"></i> ‪+91-9572216278‬</p>
        <p><i class="fas fa-envelope" style="color: #f38a17;"></i> support@iconichub</p>
        <p><i class="fas fa-clock" style="color: #f38a17;"></i> <span id="current-time">--:--</span></p>
        <p id="office-status" style="margin: 5px 0; font-weight:bold;"></p>
      </div>

      <!-- Newsletter -->
      <div style="flex: 1 1 250px;">
        <h4 style="color: #f38a17;">Subscribe</h4>
        <p style="line-height: 1.6;">Stay updated with our latest products and colleion.</p>
        <form style="display: flex; gap: 10px; margin-top: 10px;">
          <input type="email" placeholder="Your Email" required style="flex: 1; padding: 7px; border: none; border-radius: 5px;">
          <button type="submit" style="background: #f38a17; border: none; padding: 7px 15px; border-radius: 5px; color: #000; font-weight: bold;">Send</button>
        </form>
      </div>
    </div>

    <!-- Social & Copyright -->
    <div style="border-top: 1px solid #333; margin-top: 40px; padding-top: 20px; text-align: center;">
      <div style="margin-bottom: 15px;">
        <a href="#" style="color: #f38a17; margin: 0 10px;"><i class="fab fa-instagram"></i></a>
        <a href="#" style="color: #f38a17; margin: 0 10px;"><i class="fab fa-twitter"></i></a>
        <a href="#" style="color: #f38a17; margin: 0 10px;"><i class="fab fa-youtube"></i></a>
        <a href="#" style="color: #f38a17; margin: 0 10px;"><i class="fab fa-linkedin-in"></i></a>
      </div>
      <p style="color: #888;">&copy; <span id="year"></span> Iconic Hub. All Rights Reserved.</p>
    </div>
  </div>
</footer>

<!-- Font Awesome -->
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

<!-- Working Clock + Office Time Script -->
<script>
  function updateTime() {
    const timeElement = document.getElementById("current-time");
    const officeNote = document.getElementById("office-status");

    const now = new Date();
    let hours = now.getHours();
    const mins = now.getMinutes().toString().padStart(2, '0');
    const secs = now.getSeconds().toString().padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';

    const currentHour24 = hours;
    hours = hours % 12 || 12; // Convert to 12-hour format

    // ✅ Correct template literal with backticks

    const timeString = `${hours.toString().padStart(2, '0')}:${mins}:${secs} ${ampm}`;
    timeElement.textContent = timeString;

    const day = now.getDay(); // Sunday = 0
    const isSunday = day === 0;

    if (isSunday) {
      officeNote.textContent = "Sunday: Office Closed";
      officeNote.style.color = "#ff4c4c";
    } else if (currentHour24 >= 10 && currentHour24 < 22) {
      officeNote.textContent = "Office Time: 10:00 AM to 10:00 PM (Open Now)";
      officeNote.style.color = "#f38a17";
    } else {
      officeNote.textContent = "Office Time: 10:00 AM to 10:00 PM (Closed Now)";
      officeNote.style.color = "#ff4c4c";
    }
  }

  setInterval(updateTime, 1000);
  updateTime();

  // Fix year ID reference
  document.getElementById("year").textContent = new Date().getFullYear();
</script>

