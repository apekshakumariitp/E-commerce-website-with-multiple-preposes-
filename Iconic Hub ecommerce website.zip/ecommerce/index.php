<?php include('header.php'); ?>

<style>
/* Hero Background Slideshow */
/* Hero Section - Static Background */
.hero {
  height: 85vh;
  width: 100%;
  background: url('back_img/banner3.0.png') no-repeat center center/cover;
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
  color: #fff;
}

.hero::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0; bottom: 0;
  /* background-color: rgba(0, 0, 0, 0.4);  */
  
  /* Optional overlay */
  z-index: 1;
}

.hero-content {
  position: relative;
  z-index: 2;
  padding: 0 20px;
}

.hero-content h1 {
  font-size: 3rem;
  font-weight: bold;
  color: #fff;
}

.hero-btn {
  padding: 12px 24px;
  background-color: #f38a17;
  border: none;
  color: #000;
  font-weight: bold;
  border-radius: 5px;
  text-decoration: none;
  margin-top: 60px;
  display: inline-block;
  transition: 0.3s;
}

.hero-btn:hover {
  background: #fff;
  color: #f38a17;
}




@media (max-width: 767px) {
  .hero {
    background: url('back_img/mobile2.0.png') no-repeat center center/cover;
  }
  .hero-btn{
    margin-top: 88px;
    padding: 12px 10px;
  }
}
</style>
<!-- Hero Section -->
<section class="hero" id="home">
  <div class="hero-content">
    <!-- <h1>Welcome to Charlie Creation</h1> -->
    <a href="#about" class="hero-btn">Explore Our Work</a>
  </div>
</section>

<!-- About Section -->
  <style>

.about-section {
  padding: 60px 20px;
  background-color: #111;
}

/* .container {
  max-width: 1100px;
  margin: auto;
} */

h1 {
  font-size: 36px;
  color: #f38a17;
  margin-bottom: 10px;
}

.tagline {
  font-size: 20px;
  color: #ccc;
  margin-bottom: 40px;
}

.about-content {
  display: flex;
  flex-wrap: wrap;
  gap: 40px;
  align-items: center;
}

.about-text {
  flex: 1 1 55%;
}

.about-text p {
  font-size: 17px;
  line-height: 1.7;
  margin-bottom: 20px;
  color: #ddd;
}

.about-text .highlight {
  color: #f38a17;
  font-weight: 600;
}

.about-text .cta a {
  color: #f38a17;
  text-decoration: none;
  border-bottom: 1px solid #f38a17;
  transition: 0.3s ease;
}

.about-text .cta a:hover {
  color: #fff;
  border-bottom: 1px solid #fff;
}

.about-image {
  flex: 1 1 40%;
}

.about-image img {
  width: 100%;
  border-radius: 12px;
  /* box-shadow: 0 0 20px rgba(243, 138, 23, 0.4); */
}

@media (max-width: 768px) {
  .about-content {
    flex-direction: column;
  }

  h1 {
    font-size: 28px;
  }
}

  </style>

  <section class="about-section" id="about">
    <div class="container">
      <h1 class="fw-bold">About  Iconic Hub </h1>
      <p class="tagline" style="font-family:'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif ;">Style. Quality. Confidence.</p>

      <div class="about-content">
        <div class="about-text">
          <p><strong> Iconic Hub </strong> We’re your go-to style destination, offering a curated collection of <span class="highlight">clothing</span>, trendy <span class="highlight">footwear</span>, and stylish <span class="highlight">handbags</span> to elevate your everyday look.</p>

<p>We don’t just sell fashion—we deliver confidence. From everyday essentials to statement pieces, our goal is to bring you designs that are chic, functional, and unforgettable.</p>

<p>Our team is passionate about style, quality, and trends. We believe fashion should not only look stunning—but also feel amazing to wear.</p>

<p class="cta">Step up your style game today. <a href="contact.php">Shop Now →</a></p>

        </div>

        <div class="about-image">
          <img src="back_img/team.png" alt="Iconic Hub Team">
        </div>
        
      </div>
    </div>
  </section>

  <!-- Include Swiper CSS & JS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />
<script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>

<style>
  .container {
    width: 100%;
    max-width: 1200px;
    margin: auto;
    padding: 0 15px;
  }

  .feedback-modern-section {
    background: #000000ff;
    padding: 60px 20px;
  }

  .feedback-modern-section h2 {
    color: #f38a17;
    text-align: center;
    margin-bottom: 40px;
    font-size: 32px;
  }

  .feedback-modern-wrapper {
    display: flex;
    flex-wrap: wrap;
    gap: 30px;
    justify-content: space-between;
  }

  .feedback-form-container {
    flex: 1 1 380px;
    background: #1c1c1c;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 0 10px rgba(0,0,0,0.3);
  }

  .feedback-form-container h3 {
    color: #fff;
    margin-bottom: 20px;
    font-size: 20px;
  }

  #feedback-form {
    display: flex;
    flex-direction: column;
    gap: 15px;
  }

  #feedback-form input,
  #feedback-form textarea {
    padding: 12px;
    border: none;
    border-radius: 6px;
    background: #1e1e1e;
    color: #fff;
    font-size: 15px;
  }

  #feedback-form button {
    background: #f38a17;
    color: #000;
    padding: 12px;
    border: none;
    border-radius: 6px;
    font-weight: bold;
    cursor: pointer;
    transition: 0.3s ease;
  }

  #feedback-form button:hover {
    background: #d37810;
  }

  .star-rating {
    display: flex;
    flex-direction: row-reverse;
    justify-content: center;
  }

  .star-rating input {
    display: none;
  }

  .star-rating label {
    font-size: 24px;
    color: #444;
    cursor: pointer;
  }

  .star-rating input:checked ~ label,
  .star-rating label:hover,
  .star-rating label:hover ~ label {
    color: #f5c518;
  }

  .feedback-carousel-box {
    flex: 1 1 600px;
  }

  .card-group {
    display: flex;
    flex-direction: column;
    gap: 20px;
  }

  .client-card {
    display: flex;
    background: #1e1e1e;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 15px rgba(243, 138, 23, 0.1);
    gap: 15px;
    align-items: flex-start;
  }

  .logo-box img {
    width: 50px;
    height: 50px;
    object-fit: cover;
    border-radius: 50%;
    border: 2px solid #f38a17;
  }

  .client-info h4 {
    color: #fff;
    margin: 0;
  }

  .client-info .stars {
    color: #f5c518;
    font-size: 16px;
    margin: 5px 0;
  }

  .client-info p {
    color: #ccc;
    font-size: 14px;
    line-height: 1.5;
    margin: 0;
  }

  .swiper-pagination-bullet {
    background: #f38a17;
    opacity: 0.6;
  }

  .swiper-pagination-bullet-active {
    opacity: 1;
  }

  @media (max-width: 768px) {
    .feedback-modern-wrapper {
      flex-direction: column;
    }

    .feedback-form-container,
    .feedback-carousel-box {
      width: 100%;
    }
  }
</style>

<section class="feedback-modern-section" id="testimonials">
  <h2 class="fw-bold">Client Feedback</h2>
  <div class="container">
    <div class="feedback-modern-wrapper">
      <!-- Feedback Form -->
      <div class="feedback-form-container">
        <form id="feedback-form">
          <h3>Leave Your Feedback</h3>
          <input type="text" id="name" placeholder="Your Name" required />
          <div class="star-rating">
            <input type="radio" name="rating" id="star5" value="5"><label for="star5">&#9733;</label>
            <input type="radio" name="rating" id="star4" value="4"><label for="star4">&#9733;</label>
            <input type="radio" name="rating" id="star3" value="3"><label for="star3">&#9733;</label>
            <input type="radio" name="rating" id="star2" value="2"><label for="star2">&#9733;</label>
            <input type="radio" name="rating" id="star1" value="1"><label for="star1">&#9733;</label>
          </div>
          <textarea id="message" rows="4" placeholder="Write your feedback..." required></textarea>
          <button type="submit">Submit</button>
        </form>
      </div>

      <!-- Feedback Carousel -->
      <div class="feedback-carousel-box">
        <div class="swiper mySwiper">
          <div class="swiper-wrapper" id="submitted-feedbacks">
            <div class="swiper-slide">
              <div class="card-group">
                <div class="client-card">
                  <div class="logo-box">
                    <img src="logo/logo.png" alt="Hub Logo">
                  </div>
                  <div class="client-info">
                    <h4>Aman Verma</h4>
                    <div class="stars">★★★★★</div>
                    <p>Great branding, I loved the experience working with your team!</p>
                  </div>
                </div>

                <div class="client-card">
                  <div class="logo-box">
                    <img src="logo/logo.png" alt="Hub Logo">
                  </div>
                  <div class="client-info">
                    <h4>Neha Sharma</h4>
                    <div class="stars">★★★★☆</div>
                    <p>Wonderful products and perfect delivery time. Thank you!</p>
                  </div>
                </div>

                <div class="client-card">
                  <div class="logo-box">
                    <img src="logo/logo.png" alt="Hub Logo">
                  </div>
                  <div class="client-info">
                    <h4>sunny Yadav</h4>
                    <div class="stars">★★★★★</div>
                    <p>Awesome animations and products quality. Great job!</p>
                  </div>
                </div>
              </div>
            </div>

            <!-- Add more swiper-slides here with more feedback -->
          </div>
          <div class="swiper-pagination"></div>
        </div>
      </div>
    </div>
  </div>
</section>

<script>
  const swiper = new Swiper(".mySwiper", {
    loop: true,
    autoplay: {
      delay: 4000,
      disableOnInteraction: false
    },
    pagination: {
      el: ".swiper-pagination",
      clickable: true
    }
  });

  document.getElementById("feedback-form").addEventListener("submit", function (e) {
    e.preventDefault();
    const name = document.getElementById("name").value;
    const message = document.getElementById("message").value;
    const rating = document.querySelector('input[name="rating"]:checked')?.value || 0;
    const stars = "★".repeat(rating) + "☆".repeat(5 - rating);

    // Find the last slide or create new if needed
    const wrapper = document.getElementById("submitted-feedbacks");
    let lastSlide = wrapper.lastElementChild;
    let cardGroup = lastSlide?.querySelector(".card-group");

    if (!cardGroup || cardGroup.children.length >= 3) {
      lastSlide = document.createElement("div");
      lastSlide.className = "swiper-slide";
      cardGroup = document.createElement("div");
      cardGroup.className = "card-group";
      lastSlide.appendChild(cardGroup);
      wrapper.appendChild(lastSlide);
      swiper.update();
    }

    const newCard = document.createElement("div");
    newCard.className = "client-card";
    newCard.innerHTML = `
      <div class="logo-box">
        <img src="logo/logo.png" alt="Hub Logo">
      </div>
      <div class="client-info">
        <h4>${name}</h4>
        <div class="stars">${stars}</div>
        <p>${message}</p>
      </div>
    `;
    cardGroup.appendChild(newCard);
    document.getElementById("feedback-form").reset();
  });
</script>





<?php include('footer.php'); ?>
