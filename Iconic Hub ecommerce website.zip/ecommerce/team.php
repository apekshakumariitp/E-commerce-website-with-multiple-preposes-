<?php include('header.php'); ?>

<section id="team" style="background:#121212; color:#fff; padding:60px 20px;">
  <div class="container" style="max-width:1200px; margin:auto;">
    <h2 style="text-align:center; color:#f38a17; margin-bottom:40px; font-weight:bold;">Meet Our Team</h2>

    <!-- Founder & Co-Founder -->
     <div style="max-width: 900px; margin:auto;">
    <div class="row" style="display:flex; flex-wrap:wrap; justify-content:center; gap:30px;">
      <div class="team-card">
        <img src="team/2.jpg" alt="Founder">
        <h4>Apeksha kumari</h4>
        <p class="position">Founder</p>
        <p class="desc">Visionary leader and creator of Charlie Creation.</p>
        <div class="social-icons">
          <a href="#"><i class="fab fa-linkedin-in"></i></a>
          <a href="#"><i class="fab fa-instagram"></i></a>
          <a href="#"><i class="fab fa-x-twitter"></i></a>
        </div>
      </div>
      <div class="team-card">
        <img src="team/1.jpg" alt="Co-Founder">
        <h4>Mayaank kumar</h4>
        <p class="position">Co-Founder</p>
        <p class="desc">Co-leading innovation and team management.</p>
        <div class="social-icons">
          <a href="#"><i class="fab fa-linkedin-in"></i></a>
          <a href="#"><i class="fab fa-instagram"></i></a>
          <a href="#"><i class="fab fa-x-twitter"></i></a>
        </div>
      </div>
    </div>
    </div>

    <!-- Team Heads -->
    <h3 style="text-align:center; margin:50px 0 20px; color:#f38a17;">Team Heads</h3>
    <div class="row">
      <div class="team-card">
        <img src="team/3.jpg" alt="Graphic Head">
        <h4>Apeksha kumari</h4>
        <p class="position">Human Resources</p>
        <p class="desc">Manage All Hiring for all department.</p>
        <div class="social-icons">
          <a href="#"><i class="fab fa-behance"></i></a>
          <a href="#"><i class="fab fa-instagram"></i></a>
        </div>
      </div>
      <div class="team-card">
        <img src="team/4.jpg" alt="Developer Head">
        <h4> Mayank kumar </h4>
        <p class="position">Marketing Head</p>
        <p class="desc">Heads all Marketing and sell's.</p>
        <div class="social-icons">
          <a href="#"><i class="fab fa-github"></i></a>
          <a href="#"><i class="fab fa-linkedin-in"></i></a>
        </div>
      </div>
      <div class="team-card">
        <img src="team/5.jpg" alt="Video Editor Head">
        <h4>Roy patrick</h4>
        <p class="position">Digital Marketing</p>
        <p class="desc">Manages video editing and visual storytelling.</p>
        <div class="social-icons">
          <a href="#"><i class="fab fa-youtube"></i></a>
          <a href="#"><i class="fab fa-instagram"></i></a>
        </div>
      </div>
    </div>

    <!-- Our Team -->
    <h3 style="text-align:center; margin:50px 0 20px; color:#f38a17;">Our Team</h3>
    <div class="row">
      <!-- Repeat this block for each team member -->
      <div class="team-card">
        <img src="team/6.jpg" alt="Team Member">
        <h4>Aman Kumar</h4>
        <p class="position">UI Designer</p>
        <p class="desc">Designs user-friendly web experiences.</p>
        <div class="social-icons">
          <a href="#"><i class="fab fa-instagram"></i></a>
        </div>
      </div>

       <div class="team-card">
        <img src="team/7.jpg" alt="Team Member">
        <h4>Surbhi Gupta</h4>
        <p class="position">Graphic Designer</p>
        <p class="desc">Designs user-friendly web experiences.</p>
        <div class="social-icons">
          <a href="#"><i class="fab fa-instagram"></i></a>
        </div>
      </div>

       <div class="team-card">
        <img src="team/8.jpg" alt="Team Member">
        <h4>Alok Rajput</h4>
        <p class="position">Video Editor</p>
        <p class="desc">Designs user-friendly web experiences.</p>
        <div class="social-icons">
          <a href="#"><i class="fab fa-instagram"></i></a>
        </div>
      </div>

       <div class="team-card">
        <img src="team/9.jpg" alt="Team Member">
        <h4>Apeksha Kumari</h4>
        <p class="position">Web Developer</p>
        <p class="desc">Designs user-friendly web experiences.</p>
        <div class="social-icons">
          <a href="#"><i class="fab fa-instagram"></i></a>
        </div>
      </div>

       <!-- <div class="team-card">
        <img src="images/team1.jpg" alt="Team Member">
        <h4>Aman Kumar</h4>
        <p class="position">UI Designer</p>
        <p class="desc">Designs user-friendly web experiences.</p>
        <div class="social-icons">
          <a href="#"><i class="fab fa-instagram"></i></a>
        </div>
      </div>

       <div class="team-card">
        <img src="images/team1.jpg" alt="Team Member">
        <h4>Aman Kumar</h4>
        <p class="position">UI Designer</p>
        <p class="desc">Designs user-friendly web experiences.</p>
        <div class="social-icons">
          <a href="#"><i class="fab fa-instagram"></i></a>
        </div>
      </div>

       <div class="team-card">
        <img src="images/team1.jpg" alt="Team Member">
        <h4>Aman Kumar</h4>
        <p class="position">UI Designer</p>
        <p class="desc">Designs user-friendly web experiences.</p>
        <div class="social-icons">
          <a href="#"><i class="fab fa-instagram"></i></a>
        </div>
      </div>

       <div class="team-card">
        <img src="images/team1.jpg" alt="Team Member">
        <h4>Aman Kumar</h4>
        <p class="position">UI Designer</p>
        <p class="desc">Designs user-friendly web experiences.</p>
        <div class="social-icons">
          <a href="#"><i class="fab fa-instagram"></i></a>
        </div>
      </div> -->
      <!-- Add 7 more team cards similarly -->
    </div>
  </div>
</section>

<!-- CSS -->
<style>
  .team-card {
    flex: 1 1 250px;
    background: #1c1c1c;
    padding: 20px;
    border-radius: 12px;
    text-align: center;
    box-shadow: 0 0 8px rgba(0,0,0,0.4);
  }
  .team-card img {
    width: 100%;
    aspect-ratio: 1/1;
    object-fit: cover;
    border-radius: 10px;
    margin-bottom: 15px;
  }
  .team-card h4 {
    margin: 0;
    color: #f38a17;
  }
  .team-card .position {
    font-size: 14px;
    color: #ccc;
    margin: 5px 0;
  }
  .team-card .desc {
    font-size: 13px;
    color: #aaa;
    margin-bottom: 10px;
  }
  .team-card .social-icons a {
    color: #f38a17;
    margin: 0 5px;
    font-size: 16px;
  }
  .row {
    display: flex;
    flex-wrap: wrap;
    gap: 30px;
    justify-content: center;
  }
  @media (max-width: 768px) {
    .team-card {
      flex: 1 1 100%;
    }
  }
</style>


<?php include('footer.php'); ?>