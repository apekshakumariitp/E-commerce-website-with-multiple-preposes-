<?php include('header.php'); ?>

  <style>
    /* body {
      background: #121212;
      color: #fff;
      font-family: sans-serif;
      margin: 0;
      padding: 0;
    } */
    .container {
      max-width: 1052px;
      justify-items: center;
      padding: 10px;
    }
    .filters, .categories {
      display: flex;
      gap: 10px;
      flex-wrap: wrap;
      margin-bottom: 20px;
    }
    select, button {
      padding: 8px;
      border-radius: 5px;
      border: none;
      background: #1c1c1c;
      color: #fff;
    }
    .categories button.active {
      background: #f38a17;
      color: #000;
    }
    .product-grid {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
    }
    .product-card {
      background: #1c1c1c;
      padding: 15px;
      border-radius: 10px;
      width: 240px;
      box-shadow: 0 0 8px #000;
      text-align: center;
    }
    .product-card img {
      width: 100%;
      height: 200px;
      object-fit: cover;
      border-radius: 8px;
    }
    .product-card h4 { color: #f38a17; }
    .product-card .price { color: #ccc; font-size: 14px; }
    .product-card input.qty {
      width: 60px;
      padding: 5px;
      margin: 5px;
      text-align: center;
    }
    .product-card button {
      background: #f38a17;
      color: #000;
      font-weight: bold;
      border-radius: 5px;
      padding: 6px 12px;
      cursor: pointer;
    }
    .product-image-hover {
     position: relative;
     width: 100%;
     height: 200px;
     overflow: hidden;
     border-radius: 8px;
     margin-bottom: 10px;
    }
    .product-image-hover img {
     width: 100%;
     height: 100%;
     object-fit: cover;
     transition: opacity 0.4s ease;
     position: absolute;
     top: 0;
     left: 0;
    }

    .product-image-hover .main-img {
     opacity: 1;
     z-index: 1;
    }

    .product-image-hover .hover-img {
     opacity: 0;
     z-index: 2;
    }

    .product-image-hover:hover .main-img {
     opacity: 0;
    }

    .product-image-hover:hover .hover-img {
     opacity: 1;
    }
</style>

  <div class="container"><div class="categories">
  <button class="category-btn active" data-category="all">All</button>
  <button class="category-btn" data-category="tshirt">clothes</button>
  <button class="category-btn" data-category="jogger">Shose</button>
  <button class="category-btn" data-category="Hand bag"> Hand bag </button>
  <!-- <button class="category-btn" data-category="cap"> Hand bag </button> -->
</div>

<div class="filters">
  <select id="filter-gender" onchange="applyFilters()">
    <option value="">Gender</option>
    <option value="men">Men</option>
    <option value="women">Women</option>
  </select>
  <select id="filter-size" onchange="applyFilters()">
    <option value="">Size</option>
    <option value="s">S</option>
    <option value="m">M</option>
    <option value="l">L</option>
    <option value="xl">XL</option>
  </select>
  <select id="filter-style" onchange="applyFilters()">
    <option value="">Style</option>
    <option value="casual">Casual</option>
    <option value="sport">Sport</option>
  </select>
  <select id="filter-print" onchange="applyFilters()">
    <option value="">Print</option>
    <option value="plain">Plain</option>
    <option value="printed">Printed</option>
  </select>
  <button onclick="checkout()">Buy Now (WhatsApp)</button>
</div>

<div class="product-grid" id="productGrid">
  <!-- Product Cards -->
  <div class="product-card" data-category="tshirt" data-gender="men" data-size="m" data-style="casual" data-print="printed">
    <div class="product-image-hover">
      <img src="product/tshirt2.jpg" alt="Front View" class="main-img">
     <img src="product/tshirt.jpg" alt="Back View" class="hover-img">
    </div>
    <h4>Black Cotton T-Shirt</h4>
    <div class="price">₹599</div>
    <input type="number" min="1" value="1" class="qty">
    <button onclick="addToCart(this)">Add</button>
  </div>

    <div class="product-card" data-category="jogger" data-gender="women" data-size="l" data-style="sport" data-print="plain">
   <div class="product-image-hover">
  <img src="product/sb.png" alt="Front View" class="main-img">
  <img src="product/sb.png" alt="Back View" class="hover-img">
</div>
    <h4>Black Shoes </h4>
    <div class="price">₹799</div>
    <input type="number" min="1" value="1" class="qty">
    <button onclick="addToCart(this)">Add</button>
  </div>
  
 <div class="product-card" data-category="Hand bag" data-gender="women" data-size="m" data-style="casual" data-print="printed">
   <div class="product-image-hover">
    <img src="product/b1.jpeg" alt="Front View" class="main-img">
    <img src="product/b2.jpeg" alt="Back View" class="hover-img">
   </div>
   <h4>Hand bag</h4>
   <div class="price">₹299</div>
   <input type="number" min="1" value="1" class="qty">
   <button onclick="addToCart(this)">Add</button>
  </div>
  
  <div class="product-card" data-category="tshirt" data-gender="men" data-size="m" data-style="casual" data-print="printed">
    <div class="product-image-hover">
      <img src="product/tshirt2.jpg" alt="Front View" class="main-img">
     <img src="product/tshirt.jpg" alt="Back View" class="hover-img">
    </div>
    <h4>Black Cotton T-Shirt</h4>
    <div class="price">₹599</div>
    <input type="number" min="1" value="1" class="qty">
    <button onclick="addToCart(this)">Add</button>
  </div>

    <div class="product-card" data-category="jogger" data-gender="women" data-size="l" data-style="sport" data-print="plain">
   <div class="product-image-hover">
  <img src="product/sb.png" alt="Front View" class="main-img">
  <img src="product/sb.png" alt="Back View" class="hover-img">
</div>
    <h4>Black Shoes </h4>
    <div class="price">₹799</div>
    <input type="number" min="1" value="1" class="qty">
    <button onclick="addToCart(this)">Add</button>
  </div>

<div class="product-card" data-category="Hand bag" data-gender="women" data-size="m" data-style="casual" data-print="printed">
   <div class="product-image-hover">
    <img src="product/b1.jpeg" alt="Front View" class="main-img">
    <img src="product/b2.jpeg" alt="Back View" class="hover-img">
   </div>
   <h4>Hand bag</h4>
   <div class="price">₹299</div>
   <input type="number" min="1" value="1" class="qty">
   <button onclick="addToCart(this)">Add</button>
  </div>
  <!-- <div class="product-card" data-category="Shoes" data-gender="men" data-size="l" data-style="sport" data-print="plain">
   <div class="product-image-hover">
  <img src="products/s.png" alt="Front View" class="main-img">
  <img src="products/s4.png" alt="Back View" class="hover-img">
</div>
    <h4>RED Shoes</h4>
    <div class="price">₹799</div>
    <input type="number" min="1" value="1" class="qty">
    <button onclick="addToCart(this)">Add</button>
  </div> -->

  <div class="product-card" data-category="tshirt" data-gender="women" data-size="m" data-style="casual" data-print="printed">
    <div class="product-image-hover">
     <img src="product/tshirt2.jpg" alt="Front View" class="main-img">
     <img src="product/tshirt.jpg" alt="Back View" class="hover-img">
   </div>
    <h4>Black Cotton T-Shirt</h4>
    <div class="price">₹299</div>
    <input type="number" min="1" value="1" class="qty">
    <button onclick="addToCart(this)">Add</button>
  </div>
   <div class="product-card" data-category="Hand bag" data-gender="women" data-size="m" data-style="casual" data-print="printed">
   <div class="product-image-hover">
    <img src="product/b1.jpeg" alt="Front View" class="main-img">
    <img src="product/b2.jpeg" alt="Back View" class="hover-img">
   </div>
   <h4>Hand bag</h4>
   <div class="price">₹299</div>
   <input type="number" min="1" value="1" class="qty">
   <button onclick="addToCart(this)">Add</button>
  </div>
  

  <div class="product-card" data-category="jogger" data-gender="women" data-size="l" data-style="sport" data-print="plain">
   <div class="product-image-hover">
  <img src="product/s1.png" alt="Front View" class="main-img">
  <img src="product/s1.png" alt="Back View" class="hover-img">
</div>
    <h4>Gray Shoes</h4>
    <div class="price">₹799</div>
    <input type="number" min="1" value="1" class="qty">
    <button onclick="addToCart(this)">Add</button>
  </div>
  

  <div class="product-card" data-category="tshirt" data-gender="men" data-size="m" data-style="casual" data-print="printed">
    <div class="product-image-hover">
      <img src="product/tshirt2.jpg" alt="Front View" class="main-img">
     <img src="product/tshirt.jpg" alt="Back View" class="hover-img">
    </div>
    <h4>Black Cotton T-Shirt</h4>
    <div class="price">₹599</div>
    <input type="number" min="1" value="1" class="qty">
    <button onclick="addToCart(this)">Add</button>
  </div>

  <div class="product-card" data-category="jogger" data-gender="women" data-size="l" data-style="sport" data-print="plain">
   <div class="product-image-hover">
  <img src="product/sb.png" alt="Front View" class="main-img">
  <img src="product/sb.png" alt="Back View" class="hover-img">
</div>
    <h4>Red Shoes</h4>
    <div class="price">₹799</div>
    <input type="number" min="1" value="1" class="qty">
    <button onclick="addToCart(this)">Add</button>
  </div>

     <div class="product-card" data-category="Hand bag" data-gender="women" data-size="m" data-style="casual" data-print="printed">
   <div class="product-image-hover">
    <img src="product/b1.jpeg" alt="Front View" class="main-img">
    <img src="product/b2.jpeg" alt="Back View" class="hover-img">
   </div>
   <h4>Hand bag</h4>
   <div class="price">₹299</div>
   <input type="number" min="1" value="1" class="qty">
   <button onclick="addToCart(this)">Add</button>
  </div>

  <!-- Add More Product Cards -->

</div>

  </div>  
  

<!-- 🛒 Cart Summary Popup -->
<div id="cartPopup" style="display:none; position:fixed; bottom:20px; right:20px; background:#1c1c1c; border:1px solid #444; color:#fff; padding:20px; border-radius:10px; z-index:9999; max-width:340px; box-shadow:0 0 10px #000;">
  <div style="display:flex; justify-content:space-between; align-items:center;">
    <h4 style="margin:0; color:#f38a17;">🛒 Cart Summary</h4>
    <span onclick="closeCartPopup()" style="cursor:pointer; font-size:20px;">&times;</span>
  </div>
  <ul id="cartItems" style="list-style:none; padding-left:0; max-height:220px; overflow-y:auto; margin:10px 0;"></ul>
  <div style="margin-top:10px;">
    <strong id="totalPrice">Total: ₹0</strong>
  </div>
  <button onclick="sendWhatsAppCart()" style="width:100%; margin-top:15px; background:#f38a17; color:#000; padding:10px 15px; border:none; border-radius:5px; font-weight:bold; cursor:pointer;">
    Buy Now on WhatsApp
  </button>
</div>



<script>
  let cart = [];

  // Category filter
  document.querySelectorAll(".category-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".category-btn").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");

      const cat = btn.dataset.category;
      document.querySelectorAll(".product-card").forEach(card => {
        card.style.display = (cat === 'all' || card.dataset.category === cat) ? "block" : "none";
      });
      applyFilters();
    });
  });

  function applyFilters() {
    const gender = document.querySelector("#filter-gender").value;
    const size = document.querySelector("#filter-size").value;
    const style = document.querySelector("#filter-style").value;
    const print = document.querySelector("#filter-print").value;

    document.querySelectorAll(".product-card").forEach(card => {
      const matchesGender = !gender || card.dataset.gender === gender;
      const matchesSize = !size || card.dataset.size === size;
      const matchesStyle = !style || card.dataset.style === style;
      const matchesPrint = !print || card.dataset.print === print;
      if (matchesGender && matchesSize && matchesStyle && matchesPrint) {
        if (document.querySelector(".category-btn.active").dataset.category === "all" || card.dataset.category === document.querySelector(".category-btn.active").dataset.category) {
          card.style.display = "block";
        }
      } else {
        card.style.display = "none";
      }
    });
  }

  // Add to Cart with popup
  function addToCart(btn) {
    const card = btn.closest(".product-card");
    const name = card.querySelector("h4").innerText;
    const price = parseInt(card.querySelector(".price").innerText.replace("₹", ""));
    const qty = parseInt(card.querySelector(".qty").value);
    const img = card.querySelector(".main-img").getAttribute("src");

    if (!name || !price || qty < 1) return;

    const existing = cart.find(item => item.name === name);
    if (existing) {
      existing.qty += qty;
    } else {
      cart.push({ name, price, qty, img });
    }

    renderCart();
    showCartPopup();
  }

  function renderCart() {
    const list = document.getElementById("cartItems");
    const totalBox = document.getElementById("totalPrice");
    list.innerHTML = "";
    let total = 0;

    cart.forEach((item, index) => {
      total += item.price * item.qty;

      const li = document.createElement("li");
      li.style.marginBottom = "12px";

      li.innerHTML = `
        <div style="display:flex; gap:10px; align-items:center;">
          <img src="${item.img}" alt="${item.name}" style="width:40px; height:40px; border-radius:5px; object-fit:cover;">
          <div style="flex:1;">
            <strong>${item.name}</strong><br>
            ₹${item.price} × 
            <button onclick="updateQty(${index}, -1)" style="margin:0 5px;">−</button>
            ${item.qty}
            <button onclick="updateQty(${index}, 1)" style="margin:0 5px;">+</button>
            = ₹${item.price * item.qty}
          </div>
          <span onclick="removeItem(${index})" style="cursor:pointer; color:red; font-weight:bold;">❌</span>
        </div>
      `;
      list.appendChild(li);
    });

    totalBox.innerText = `Total: ₹${total}`;
  }

  function updateQty(index, change) {
    if (cart[index]) {
      cart[index].qty += change;
      if (cart[index].qty <= 0) cart.splice(index, 1);
      renderCart();
    }
  }

  function removeItem(index) {
    cart.splice(index, 1);
    renderCart();
  }

  function closeCartPopup() {
    document.getElementById("cartPopup").style.display = "none";
  }

  function showCartPopup() {
    document.getElementById("cartPopup").style.display = "block";
  }

  function sendWhatsAppCart() {
    if (cart.length === 0) return alert("Your cart is empty!");

    let message = `Hello, I want to place an order:%0A`;
    cart.forEach(item => {
      message += `• ${item.name} × ${item.qty} = ₹${item.price * item.qty}%0A`;
    });
    const total = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
    message += `%0A📦 Total: ₹${total}%0A%0A🏠 Address: [Please enter your address]`;

    const phone = "918252461180";
    window.open(`https://wa.me/${phone}?text=${message}`, '_blank');
  }

  function checkout() {
    showCartPopup();
  }
</script>



<!-- Printing Service Box -->
<div style="max-width:800px; margin:40px auto; background:#1c1c1c; color:#fff; border-radius:12px; padding:25px; box-shadow:0 0 15px rgba(0,0,0,0.4); display:flex; flex-wrap:wrap; align-items:center; gap:25px;">
  <div style="flex:1; min-width:250px;">
    <img src="logo/charlie logo website.png" alt="Printing Service" style="width:200px; border-radius:10px; height:48px; object-fit:cover;">
  </div>
  <div style="flex:2; min-width:250px;">
    <h3 style="color:#f38a17; margin-top:0;"><i class="fas fa-print"></i> Custom Printing Services</h3>
    <p style="font-size:15px; line-height:1.6; margin-bottom:15px;">
      High-quality custom printing available on T-Shirts, Hand bag, Mugs & more.<br>
      Perfect for events, branding, or gifts. Upload your design and leave the rest to us.
    </p>
    <a href="https://wa.me/918252461180?text=I%20want%20to%20request%20a%20custom%20printing%20service" target="_blank"
       style="display:inline-block; background:#f38a17; color:#000; padding:10px 18px; border-radius:6px; font-weight:bold; text-decoration:none;">
      <i class="fab fa-whatsapp"></i> Request on WhatsApp
    </a>
  </div>
</div>


<?php include('footer.php'); ?>
