<?php include('header.php'); ?>

<style>

  .section {
    padding: 60px 20px;
  }

  .section h2 {
    text-align: center;
    font-size: 36px;
    margin-bottom: 40px;
    color: #f38a17;
    font-weight: 700;
  }

  .content-box {
    max-width: 900px;
    margin: 0 auto;
    font-size: 18px;
    line-height: 1.8;
    color: #ddd;
  }

  .grid-3 {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 25px;
    margin-top: 40px;
  }

  .card {
    background: #262626;
    padding: 25px;
    border-radius: 10px;
    border: 1px solid #333;
    transition: 0.3s ease;
    text-align: center;
  }

  .card:hover {
    background: #2f2f2f;
    border-color: #f38a17;
  }

  .card h4 {
    color: #f38a17;
    margin-bottom: 10px;
  }

  .card p {
    font-size: 15px;
    color: #bbb;
  }

</style>

<!-- About Section -->
<section class="section">
  <h2>About </h2>
  <div class="content-box">
    <p>
     Iconic Hub is a fashion powerhouse based in India, offering a curated range of stylish clothing, trendy footwear, and premium handbags. We’re passionate about redefining your wardrobe — whether it’s a statement outfit, the perfect pair of shoes, or a chic accessory that completes your look.
    </p>
    <p>
     <p>
  Our philosophy is simple: 
  <strong style="color: #f38a17;">"Style. Quality. Confidence"</strong> 
  We blend fashion with functionality, ensuring every piece we offer reflects elegance, comfort, and impact. 
  With a dedicated team and a growing collection, Iconic Hub is your trusted style partner.
</p>
    </p>
  </div>
</section>

<!-- Mission / Vision / Values Section -->
<section class="section" style="background: #1f1f1f;">
  <h2>Our Core</h2>
  <div class="grid-3 container">
    <div class="card">
      <h4>Mission</h4>
      <p>To empower fashion lovers and trendsetters with handpicked clothing, footwear, and accessories that inspire confidence and style.</p>
    </div>
    <div class="card">
      <h4>Vision</h4>
      <p>To become a top-tier fashion and lifestyle brand recognized for quality, style, and trust..</p>
    </div>
    <div class="card">
      <h4>Values</h4>
      <p>Creativity, Innovation, Integrity, and 100% Client Satisfaction.</p>
    </div>
  </div>
</section>

<!-- Why Choose Us -->
<section class="section">
  <h2>Why Choose Us?</h2>
  <div class="grid-3 container">
    <div class="card">
       <h4>Trendy Clothing</h4>
    <p>Stylish apparel for every occasion — casual, formal, or festive.</p>
  </div>
  <div class="card">
    <h4>Footwear Collection</h4>
    <p>Comfortable, durable, and fashionable shoes for men and women.</p>
  </div>
  <div class="card">
    <h4>Designer Handbags</h4>
    <p>Premium handbags and accessories to complement your style.</p>
  </div>
  <div class="card">
    <h4>Seasonal Specials</h4>
    <p>Exclusive collections and offers to keep your wardrobe fresh all year.</p>
    </div>
  </div>
</section>

<?php include('footer.php'); ?>
