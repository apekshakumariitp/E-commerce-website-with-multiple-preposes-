<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Iconic Hub - Home</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
  <!-- Google Icons for Close button -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded" />

  <style>
    html { scroll-behavior: smooth; }
    body {
      margin: 0;
      font-family: 'Poppins', sans-serif;
      background-color: #000;
      color: #fff;
    }

    header {
      background-color: #121212;
      position: sticky;
      top: 0;
      z-index: 1000;
    }

    .navbar { padding: 0.8rem 1rem; }
    .navbar-brand img { max-height: 65px; width: auto; }
    .nav-link { color: #f38a17 !important; font-weight: 500; }
    .nav-link:hover { color: #ffffff !important; }
    .navbar-toggler { border: none; background: transparent; padding: 0; }
    .navbar-toggler-icon {
      background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='orange' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
      height: 30px; width: 30px;
    }

    @media (max-width: 992px) {
      .navbar-collapse { background-color: #121212; padding: 1rem; }
      .navbar-brand { flex-grow: 1; }
    }

    /* Floating Social Icons */
    .social-bar {
      position: fixed; top: 40%; left: 0;
      transform: translateY(-50%);
      display: flex; flex-direction: column; gap: 12px;
      z-index: 1000;
    }
    .social-bar a {
      display: flex; align-items: center; justify-content: center;
      width: 42px; height: 42px;
      color: #fff; background-color: #222;
      border-radius: 0 6px 6px 0;
      font-size: 20px; transition: all 0.3s ease;
    }
    .social-bar a:hover { padding-left: 6px; background-color: #f38a17; }
    .social-bar .instagram:hover { background: #e4405f; }
    .social-bar .youtube:hover { background: #ff0000; }
    .social-bar .linkedin:hover { background: #0077b5; }
    .social-bar .twitter:hover { background: #1da1f2; }
    @media (max-width: 768px) {
      .social-bar { top: auto; bottom: 10px; left: 10px; flex-direction: row; }
    }

    /* WhatsApp Floating Button */
    .whatsapp-container { position: fixed; bottom: 20px; right: 20px; z-index: 1000; }
    .whatsapp-float {
      width: 60px; height: 60px; background-color: #037b39ff;
      color: white; font-size: 28px; border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
      cursor: pointer; transition: all 0.3s ease;
    }
    .whatsapp-float:hover { background-color: #038d41ff; transform: scale(1.1); }
    .service-menu {
      display: none; position: absolute; bottom: 70px; right: 0;
      transform: translateX(-100%);
      background-color: #111; border-radius: 12px; overflow: hidden;
      box-shadow: 0 0 10px rgba(0,0,0,0.25);
    }
    .service-menu a {
      display: block; padding: 12px 16px; color: #fff;
      font-size: 15px; border-bottom: 1px solid rgba(255,255,255,0.1);
    }
    .service-menu a:hover { background-color: #f38a17; color: #000; }
    .service-menu a:last-child { border-bottom: none; }

    /* Popup Form */
    .form-popup {
      position: fixed; top: 50%; left: 50%; z-index: 2000;
      width: 100%; max-width: 720px;
      background: #fff; border: 2px solid #fff;
      transform: translate(-50%, -70%);
      opacity: 0; pointer-events: none;
    }
    .show-popup .form-popup {
      opacity: 1; pointer-events: auto;
      transform: translate(-50%, -50%);
      transition: transform 0.3s ease, opacity 0.1s;
    }
    .form-popup .close-btn {
      position: absolute; top: 12px; right: 12px;
      color: #878484; cursor: pointer;
    }
    .blur-bg-overlay {
      position: fixed; top: 0; left: 0;
      z-index: 1500; width: 100%; height: 100%;
      backdrop-filter: blur(5px); -webkit-backdrop-filter: blur(5px);
      opacity: 0; pointer-events: none; transition: 0.1s ease;
    }
    .show-popup .blur-bg-overlay { opacity: 1; pointer-events: auto; }

    .form-popup .form-box { display: flex; }
    .form-box .form-details {
      width: 100%; 
      max-width: 330px; 
      color: #fff;
      display: flex; 
      flex-direction: column; 
      justify-content: center; 
      align-items: center;
      text-align: center; 
      padding: 0 40px;
    }
    .login .form-details { background: url("images/login-img.jpg") center/cover; }
    .signup .form-details { background: url("images/signup-img.jpg") center/cover; }
    .form-box .form-content { width: 100%; padding: 35px; }
    .form-box h2 { text-align: center; margin-bottom: 29px; }
    form .input-field { position: relative; height: 50px; width: 100%; margin-top: 20px; }
    .input-field input {
      width: 100%; height: 100%; padding: 0 15px;
      border: 1px solid #717171; border-radius: 3px; outline: none;
    }
    .input-field input:focus { border: 1px solid #00bcd4; }
    .input-field label {
      position: absolute; top: 50%; left: 15px; transform: translateY(-50%);
      color: #4a4646; pointer-events: none; transition: 0.2s ease;
    }
    .input-field input:focus ~ label,
    .input-field input:valid ~ label {
      transform: translateY(-120%); color: #00bcd4; font-size: 0.75rem;
    }
    form button {
      width: 100%; margin: 25px 0; padding: 14px 0;
      background: #00bcd4; color: #fff;
      font-size: 1rem; font-weight: 500;
      border: none; border-radius: 3px;
    }
    .form-popup .signup {
  display: none; /* hide signup initially */
}
    form button:hover { background: #0097a7; }
    .form-popup.show-signup .login { 
      display: none; 
    }
    .form-popup.show-signup .signup {
       display: flex; 
      }
    @media (max-width: 760px) {
      .form-popup { width: 95%; }
      .form-box .form-details { 
        display: none; 
      }
      .form-box .form-content { 
        padding: 30px 20px; 
      }
    }
  </style>
</head>
<body>

<header>
  <nav class="navbar navbar-expand-lg">
    <div class="container-fluid d-flex align-items-center justify-content-between">
      <a class="navbar-brand" href="index.php">
        <img src="logo/Hub logo website.png" alt="Hub Creation Logo" />
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
      </button>
    </div>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0 text-center">
        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="aboutus.php">About</a></li>
        <!--<li class="nav-item"><a class="nav-link" href="services.php">Services</a></li>-->
        <li class="nav-item"><a class="nav-link" href="products.php">Products</a></li>
        <!--<li class="nav-item"><a class="nav-link" href="work.php">Work</a></li>-->
        <li class="nav-item"><a class="nav-link" href="team.php">Team</a></li>
        <li class="nav-item"><a class="nav-link" href="blog.php">Blog</a></li>
        <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
        <li class="nav-item"><a class="nav-link login-btn" href="#" style="background-color: #61616175; border-radius: 15px; font-weight: bold;">Login</a></li>
      </ul>
    </div>
  </nav>
</header>

<!-- Floating Social -->
<div class="social-bar">
  <a href="#" class="instagram"><i class="fab fa-instagram"></i></a>
  <a href="#" class="youtube"><i class="fab fa-youtube"></i></a>
  <a href="#" class="linkedin"><i class="fab fa-linkedin-in"></i></a>
  <a href="#" class="twitter"><i class="fab fa-x-twitter"></i></a>
</div>

<!-- WhatsApp -->
<div class="whatsapp-container">
  <div class="service-menu" id="serviceMenu">
    <a href="#"><i class="fas fa-tshirt"></i> Cloth's</a>
    <a href="#"><i class="fa-solid fa-shoe-prints"></i>Shose</a>
    <a href="#"><i class="fa-solid fa-graduation-cap"></i></i> Cap</a>
     <a href="#"><i class="fa fa-shopping-bag" aria-hidden="true"></i></i> Handbag</a>
  </div>
  <div class="whatsapp-float" onclick="toggleMenu()"><i class="fab fa-whatsapp"></i></div>
</div>

<!-- Login/Signup Popup -->
<div class="blur-bg-overlay"></div>
<div class="form-popup">
  <span class="close-btn material-symbols-rounded">close</span>
  <div class="form-box login">
    <div class="form-details">
      <h2>Welcome Back</h2>
      <p>Please log in to stay connected with us.</p>
    </div>
    <div class="form-content">
      <h2 style="color: #000;">LOGIN</h2>
      <form>
        <div class="input-field"><input type="text" required><label>Email</label></div>
        <div class="input-field"><input type="password" required><label>Password</label></div>
        <a href="#" class="forgot-pass-link">Forgot password?</a>
        <button type="submit">Log In</button>
      </form>
      <div class="bottom-link" style="color: #000;">Don't have an account? <a href="#" id="signup-link">Signup</a></div>
    </div>
  </div>
  
  <div class="form-box signup">
    <div class="form-details">
      <h2>Create Account</h2>
      <p>Sign up using your personal information.</p>
    </div>
    <div class="form-content">
      <h2 style="color: #000;">SIGNUP</h2>
      <form>
        <div class="input-field"><input type="text" required><label>Email</label></div>
        <div class="input-field"><input type="password" required><label>Password</label></div>
        <div class="policy-text"><input type="checkbox" id="policy"><label for="policy" style="color: #000;">I agree the <a href="#">Terms & Conditions</a></label></div>
        <button type="submit">Sign Up</button>
      </form>
      <div class="bottom-link" style="color: #000;">Already have an account? <a href="#" id="login-link">Login</a></div>
    </div>
  </div>
</div>

<script>
function toggleMenu() {
  var menu = document.getElementById('serviceMenu');
  menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
}

const showPopupBtn = document.querySelector(".login-btn");
const formPopup = document.querySelector(".form-popup");
const hidePopupBtn = formPopup.querySelector(".close-btn");
const signupLoginLink = formPopup.querySelectorAll(".bottom-link a");

// Show login popup
showPopupBtn.addEventListener("click", (e) => {
  e.preventDefault();
  document.body.classList.add("show-popup");
});

// Hide popup
hidePopupBtn.addEventListener("click", () => {
  document.body.classList.remove("show-popup");
});

// Switch forms
signupLoginLink.forEach(link => {
  link.addEventListener("click", (e) => {
    e.preventDefault();
    formPopup.classList[link.id === 'signup-link' ? 'add' : 'remove']("show-signup");
  });
});
</script>
</body>
</html>
